Package updates known problems
=================

@ionic/app-scripts 3.2.3 shows error Cannot find type definition file for '@types'. on ngc build.

com-darryncampbell-cordova-plugin-intent 2.0.0 onwards needs Android X Support. Unsupported on PGB.

typescript is needed to be less than 2.7 for @angular/compiler-cli

cordova-plugin-ionic-keyboard has problems on greater versions than 2.1.3

jszip has problems with "lie" dependency on greater versions than 3.1

promise.prototype.finally has problems on greater versions than 3.1

cordova-ios: should remain on 5.1 because of: https://github.com/apache/cordova-ios/pull/801

