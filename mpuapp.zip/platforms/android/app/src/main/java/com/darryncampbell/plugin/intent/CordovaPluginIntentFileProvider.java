package com.darryncampbell.cordova.plugin.intent;

public class CordovaPluginIntentFileProvider extends android.support.v4.content.FileProvider {
}